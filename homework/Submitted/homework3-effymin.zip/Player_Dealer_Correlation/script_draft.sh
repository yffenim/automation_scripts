#!/bin/bash

read -p 'Enter a date in 4-digit format such as "0310" for March 10th: ' date
echo "The date you have entered is $date."

read -p 'Enter the time in the following format: "XX YY" where XX is the time and YY is the AM/PM. (For example: 05 AM): ' time 

# ADD INPUT VALIDATION


am_pm=" ${time:3:4}"
search_time=${time:0:2}:00:00$am_pm
echo "The time you have entered is $search_time"

file_name=${date}_Dealer_schedule
echo "The file name to search for $date is $file_name"

output=$(cat $file_name | grep "$search_time" | awk '{print $4, $5}')
echo "The dealer who was working on $date at $search_time is: $output"
